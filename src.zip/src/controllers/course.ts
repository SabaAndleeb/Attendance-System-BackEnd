import { Course } from "../models";
import { Request , Response } from 'express';

export class CourseController {

    constructor(){}

    saveCourse = (req : Request , res : Response) => {
        Course.create(req.body , (error : any , response : any) => {
            if(error)
                return res.json({success : false, response : error});
            
            return res.json({success : true , response : response });
        });
    }

    getCourse = (req : Request , res : Response) => {

        const query = req.params ? { name : req.params.name } : {};
    
        Course.find( query , (error : any , docs : any) => {
            if(error)
                return res.json({success : false, response : error});
            
            return res.json({success : true , response : docs});
        });
    }
}