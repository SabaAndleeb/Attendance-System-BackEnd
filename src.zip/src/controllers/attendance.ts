import { Request , Response } from "express";
import { Attendance } from '../models';

export class AttendanceController {
    
    constructor(){}

    saveAttendance = (req : Request , res : Response) => {
        Attendance.create(req.body , (error : any , response : any) => {
            if(error)
                return res.json({success : false, response : error});
            
            return res.json({success : true , response : response });
        });
    }

    getAttendance = (req : Request , res : Response) => {

        const query = req.params ? {className : req.params.className , section : req.params.section , year : req.params.year } : {};
    
        Attendance.find( query , (error : any , docs : any) => {
            if(error)
                return res.json({success : false, response : error});
            
            return res.json({success : true , response : docs});
        });
    }

}