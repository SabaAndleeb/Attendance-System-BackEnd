import  mongoose, { Schema } from 'mongoose';
const ObjectId = Schema.Types.ObjectId;

export const attendanceSchema = new Schema({
   date      : { type : Date , default : new Date() },   
   status    : { type : Boolean , default : true },
   classId   : { type : ObjectId , ref : 'Classes' } ,
   student   : { type : ObjectId , ref : 'Student' },
   teacher   : { type : ObjectId , ref : 'Teacher' },
});

export const Attendance = mongoose.model('Attendance', attendanceSchema);
