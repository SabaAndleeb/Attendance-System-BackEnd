import  mongoose, { Schema } from 'mongoose';
const ObjectId = Schema.Types.ObjectId;

export const classesSchema = new Schema({
   degree     : { type : ObjectId , ref : 'Degree' , required : true },
   programme  : { type : ObjectId , ref : 'Programme' , required : true },
   courses    : { type : Array  , ref : 'Course'  , default : [] },
   students   : { type : Array  , ref : 'Student' , default : [] },
   teachers   : { type : Array  , ref : 'Teacher' , default : [] },
   section    : String ,
   part       : Number ,
   semester   : Number ,
});

export const Classes = mongoose.model('Classes', classesSchema);
