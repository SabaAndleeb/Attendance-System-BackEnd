export const CLIENT_URL   = process.env.host || 'http://localhost:4200'
export const DATABASE_URL = process.env.DATABASE || 'mongodb://localhost:27017/studentAttendanceSystem';
export const PORT         =  process.env.PORT || 3000;
export const JWTSECRET    = '@#_ST^!'